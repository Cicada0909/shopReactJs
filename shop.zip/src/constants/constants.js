export const SERVER_URL = "https://dummyjson.com/"

export const CART = "cart";