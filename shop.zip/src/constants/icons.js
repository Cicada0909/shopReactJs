// import { ReactComponent as Logo } from '../assets/icons/logo.svg'

// export const Icons = {
//     Logo,
// }