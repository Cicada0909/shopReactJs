import { createContext } from "react";

export const CustomThemeProvider = createContext("light");